<?php
echo $this->extend('layout');
echo $this->section('content');

echo $this->endSection();